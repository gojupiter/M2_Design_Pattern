
public class SoldierDecoratorShield extends SoldierDecorator{

	public SoldierDecoratorShield(Soldier sol) {
		super(sol);
		// TODO Auto-generated constructor stub
	}
	
	public boolean wardOff(int force) {
		return super.wardOff(force-6);
	}
}
