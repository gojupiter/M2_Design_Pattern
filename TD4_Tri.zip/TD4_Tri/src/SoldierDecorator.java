
public class SoldierDecorator implements Soldier {
	private Soldier soldier;
	
	public SoldierDecorator(Soldier sol) {
		this.soldier = sol;
	}
	@Override
	public int hit() {
		// TODO Auto-generated method stub
		return soldier.hit();
	}

	@Override
	public boolean wardOff(int force) {
		// TODO Auto-generated method stub
		return soldier.wardOff(force);
	}
	
    public void accept(visitorInterface v) {
		v.visit(this);
	}
    
	public String toString() {
		return soldier.toString();
	}

}
