public interface Equipment {
    int shield();
    int damage();
}
