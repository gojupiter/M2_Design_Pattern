public interface SoldierObserver {
    void update();
    void addSubject(SoldierSubject subject);
}
