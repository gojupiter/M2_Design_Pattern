public interface SoldierVisitor {
    int visit(InfantrymenProxy infantrymen);
    int visit(HorsemenProxy horsemen);
}
