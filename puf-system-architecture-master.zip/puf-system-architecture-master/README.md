puf-system-architecture
